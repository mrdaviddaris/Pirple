link to JSBin and console output:
https://jsbin.com/dajofel/1/edit?js,output

I did not understand why the console would output my comments when
they were identified with the //.
During the lesson, the instructor's output only displayed the current function.