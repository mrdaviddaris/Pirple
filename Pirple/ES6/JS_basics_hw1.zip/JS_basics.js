<!--
Created using JS Bin
http://jsbin.com

Copyright (c) 2021 by mrdaviddaris (http://jsbin.com/dajofel/1/edit)

Released under the MIT license: http://jsbin.mit-license.org
-->
<meta name="robots" content="noindex">

<script id="jsbin-javascript">
/* The Fat Rat is an electronic dance music (EDM) artist
from Germany. My youngest son introduced the family to EDM
two years ago when he started  playing the game "Geometry Dash."
Since then we follow many such musicians. My favorite song by
the Fat Rat is 'Unity'.
*/

// Objects and Arrays

var song="Unity"
var artist="The Fat Rat"
var genre="EDM"
var release="2014"
var edmTraits=["E minor", "105 bpm", "-3db", "88 Energy"];
var unityDb= -3;

// Booleans
console.log(genre === "EDM");
console.log()


console.log(edmTraits);
console.log(edmTraits.length);
console.log(edmTraits[2]);
console.log(song);
console.log(edmTraits);

</script>